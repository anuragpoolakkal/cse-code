public class officer extends employee {
	String specialization;
	}
