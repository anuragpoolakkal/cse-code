public class triangle extends shape {
	void noOfSides() {
	System.out.println("no of sides = 3");
	}
}
