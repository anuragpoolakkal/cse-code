class poly {
	public static void main (String[] args) {
		triangle t1 = new triangle ();
		rectangle r1 = new rectangle();
		hexagon h1 = new hexagon();

		t1.noOfSides();
		r1.noOfSides();
		h1.noOfSides();
	}
}
