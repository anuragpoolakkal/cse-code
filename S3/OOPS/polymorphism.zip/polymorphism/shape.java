public class shape {
void noOfSides() {
	};

}
