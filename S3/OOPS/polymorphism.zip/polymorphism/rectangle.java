public class rectangle extends shape {
	void noOfSides() {
	System.out.println("no of sides = 4");
	}
}
